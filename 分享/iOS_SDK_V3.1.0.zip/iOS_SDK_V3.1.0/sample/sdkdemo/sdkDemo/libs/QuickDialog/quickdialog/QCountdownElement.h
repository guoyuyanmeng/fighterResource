#import <Foundation/Foundation.h>


@interface QCountdownElement : QDateTimeInlineElement
@end
