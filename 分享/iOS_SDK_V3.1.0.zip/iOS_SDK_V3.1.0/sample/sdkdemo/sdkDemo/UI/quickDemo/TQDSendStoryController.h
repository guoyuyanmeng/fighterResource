//
//  TQDSendStoryController.h
//  tencentOAuthDemo
//
//  Created by 易壬俊 on 13-7-2.
//
//

#import "TQDQuickDialogController.h"

@interface TQDSendStoryController : TQDQuickDialogController

@end
