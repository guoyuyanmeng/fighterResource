//
//  TQDLoginController.h
//  tencentOAuthDemo
//
//  Created by 易壬俊 on 13-6-18.
//
//

#import "TQDQuickDialogController.h"

@interface TQDLoginController : TQDQuickDialogController

@end
